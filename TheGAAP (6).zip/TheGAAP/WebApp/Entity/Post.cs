﻿// using Microsoft.AspNetCore.Http.HttpResults;
// using static System.Net.Mime.MediaTypeNames;
// using static System.Runtime.InteropServices.JavaScript.JSType;
// using System;
// using System.ComponentModel.DataAnnotations;
// using System.ComponentModel.DataAnnotations.Schema;
//
// namespace WebApp.Entity
// {
//     public class Category
//     {
//         public int Id { get; set; }
//         public string Name { get; set; }
//         public string Slug { get; set; }
//         public Category ParentCategory { get; set; }
//         public ICollection<Category> ChildCategories { get; set; }
//         public ICollection<Post> Posts { get; set; }
//     }
//
//     [Table("wp_posts")]
//     public class Post
//     {
//
//         [Key]
//         [Column("ID")]
//         public long ID { get; set; }
//
//
//         [Column("post_author")]
//         public long post_author { get; set; }
//
//
//         public DateTime post_date { get; set; }
//
//         public DateTime post_date_gmt { get; set; }
//
//
//         public string post_content { get; set; }
//
//         public string post_title { get; set; }
//
//         public string post_excerpt { get; set; }
//
//         public string post_status { get; set; }
//
//         public string comment_status { get; set; }
//
//         public string ping_status { get; set; }
//
//         public string post_password { get; set; }
//
//         public string post_name { get; set; }
//
//         public string to_ping { get; set; }
//
//         public string pinged { get; set; }
//
//         public DateTime post_modified { get; set; }
//
//         public DateTime post_modified_gmt { get; set; }
//
//         public string post_content_filtered { get; set; }
//
//         public long post_parent { get; set; }
//
//         public string guid { get; set; }
//
//         public int menu_order { get; set; }
//
//         public string post_type { get; set; }
//
//         public string post_mime_type { get; set; }
//
//         public long comment_count { get; set; }
//
//     }
// }
