﻿using System.ComponentModel.DataAnnotations;

namespace WebApp.Entity
{
    

    public class Contact
    {
        public int ContactId { get; set; }

        [Required]
        public string Email { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Message { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}
