﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApp.Context;
using WebApp.Migrations;

namespace WebApp.Services;

public interface IPostService
{
    public Task<List<WpPost>> GetRecentPosts();
    Task<List<WpPost>> GetPostsByCategorySlug(string categorySlug);
}

public class PostService(MyDbContext dbContext, ILogger<PostService> logger) : IPostService
{
    public async Task<List<WpPost>> GetRecentPosts()
    {
        try
        {
            var posts =  await dbContext.WpPosts
                .OrderByDescending(p => p.PostDate)
                .Take(9)
                .ToListAsync();

            dbContext.Dispose();

            return posts;
        }
        catch (Exception e)
        {
            logger.LogError(e, "Error getting recent posts");
            throw;
        }
    }

    public async Task<List<WpPost>> GetPostsByCategorySlug(string categorySlug)
    {
        try
        {
            const string sql = "SELECT * FROM wp_posts WHERE ID IN (SELECT object_id FROM wp_term_relationships WHERE term_taxonomy_id IN (SELECT term_taxonomy_id FROM wp_term_taxonomy WHERE taxonomy = 'category' AND term_id IN (SELECT term_id FROM wp_terms WHERE slug = {0})))";

            return await dbContext.WpPosts.FromSqlRaw(sql, categorySlug).ToListAsync();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }
}