﻿using Microsoft.EntityFrameworkCore;
using WebApp.Context;
using WebApp.Models;

namespace WebApp.Services
{
    public interface ICategoriesService
    {
        Task<List<Category>> GetCategories();
    }

    public class CategoriesService : ICategoriesService
    {
        private readonly MyDbContext _dbContext;

        public CategoriesService(MyDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<List<Category>> GetCategories()
        {
            // Assuming you have a DbSet<CategoryResult> CategoriesResults in MyDbContext
            var query = @"
                SELECT
                    parent.name AS ParentName,
                    child.name AS ChildName,
                    child.slug AS ChildSlug,
                    COUNT(p.ID) AS PostCount
                FROM
                    wp_term_taxonomy AS parent_taxonomy
                        JOIN
                    wp_terms AS parent ON parent_taxonomy.term_id = parent.term_id
                        LEFT JOIN
                    wp_term_taxonomy AS child_taxonomy ON parent_taxonomy.term_id = child_taxonomy.parent
                        LEFT JOIN
                    wp_terms AS child ON child_taxonomy.term_id = child.term_id
                        LEFT JOIN
                    wp_term_relationships AS rel ON child_taxonomy.term_taxonomy_id = rel.term_taxonomy_id
                        LEFT JOIN
                    wp_posts AS p ON rel.object_id = p.ID AND p.post_status = 'publish'
                WHERE
                    parent_taxonomy.taxonomy = 'category'
                  AND (child_taxonomy.taxonomy = 'category' OR child_taxonomy.taxonomy IS NULL)
                GROUP BY
                    parent.name, child.name, child.slug
                HAVING
                    COUNT(p.ID) > 0
                ORDER BY
                    parent.name, child.name";

            using var context = new MyDbContext();
            var categoryResults = await context.Database.SqlQueryRaw<CategoryResult>(query).ToListAsync();

            var categories = categoryResults
                .GroupBy(cr => cr.ParentName)
                .Select(g => new Category
                {
                    Name = g.Key,
                    PostCount = g.Sum(cr => cr.PostCount), 
                    Children = g.Where(cr => !string.IsNullOrEmpty(cr.ChildName))
                        .Select(cr => new Category
                        {
                            Name = cr.ChildName,
                            Slug = cr.ChildSlug,
                            PostCount = cr.PostCount
                        }).ToList()
                }).ToList();
            
            return categories;
        }
    }
}
