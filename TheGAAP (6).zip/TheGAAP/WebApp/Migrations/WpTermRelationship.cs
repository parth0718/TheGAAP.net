﻿using System;
using System.Collections.Generic;

namespace WebApp.Migrations;

public partial class WpTermRelationship
{
    public ulong ObjectId { get; set; }

    public ulong TermTaxonomyId { get; set; }

    public int TermOrder { get; set; }
    
    public WpPost WpPost { get; set; } = null!;
    
    public WpTermTaxonomy WpTermTaxonomy { get; set; } = null!;
    
    public WpTerm WpTerm { get; set; } = null!;
}
