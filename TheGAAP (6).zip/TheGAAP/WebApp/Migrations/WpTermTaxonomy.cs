﻿using System;
using System.Collections.Generic;

namespace WebApp.Migrations;

public partial class WpTermTaxonomy
{
    public ulong TermTaxonomyId { get; set; }

    public ulong TermId { get; set; }

    public string Taxonomy { get; set; } = null!;

    public string Description { get; set; } = null!;

    public ulong Parent { get; set; }

    public long Count { get; set; }
    
    public virtual ICollection<WpTerm> WpTerms { get; set; } = null!;
    
    public virtual ICollection<WpTermRelationship> WpTermRelationships { get; set; } = null!;
    
    public virtual WpTerm WpTerm { get; set; } = null!;
    
    

}
