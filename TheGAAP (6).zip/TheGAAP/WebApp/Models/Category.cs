﻿namespace WebApp.Models;

public class Category
{
    public string Name { get; set; }
    public string Slug { get; set; }
    public int PostCount { get; set; }
    public List<Category> Children { get; set; } = new List<Category>();
}