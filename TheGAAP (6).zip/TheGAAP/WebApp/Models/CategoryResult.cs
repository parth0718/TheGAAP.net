﻿namespace WebApp.Models;

public class CategoryResult
{
    public string ParentName { get; set; }
    public string ChildName { get; set; }
    public string ChildSlug { get; set; }
    public int PostCount { get; set; }
}