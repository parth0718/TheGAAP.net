﻿namespace WebApp.Models;


public class PostModel
{
    public string Image { get; set; }
    public string Title { get; set; }
    public string Content { get; set; }
    public string Posted { get; set; }
}